package org.example;

import Utils.StringUtils;
import javassist.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.*;

public class MemoryTransformer implements ClassFileTransformer {
    public static final Map<String, String> suspiciousClassAndMethod = new HashMap<String, String>() {{
        put("AbstractHandlerMethodMapping", "registerMapping");
        put("AbstractUrlHandlerMapping", "registerHandler");
        put("java.lang.Field", "get");
        put("FilterDef", "setFilterName");
        put("StandardContext", Arrays.toString(new String[]{"addApplicationEventListener", "addServletMappingDecoded", "addServletMapping"}));
        put("Testing", "runCal");
        put("ProcessBuilder", "start");
    }};
    //    private static List<StackTraceElement[]> stackTraceList = new ArrayList<>();
    public static List<ClassPool> systemClassPool = new ArrayList<>();

    //    ====================================================================================================================
    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        boolean isSuspiciousClass = false;
        ClassLoader contextLoader = Thread.currentThread().getContextClassLoader();
//        System.out.println("==================\nTRansformer executed");
//        System.out.println("ClassName: " + className);
//        System.out.println("Classloader: " + loader);
        String onlyClassName = className.substring(className.lastIndexOf("/") + 1);
        for (String malClassName : suspiciousClassAndMethod.keySet()) {
            if (onlyClassName.equals(malClassName)) {
                isSuspiciousClass = true;
                break;
            }
        }
        if (isSuspiciousClass) {
            try {
                System.out.println("Suspicious class: " + className);
                ClassPool.getDefault().insertClassPath(new ClassClassPath(classBeingRedefined));
                ClassPool classPool = ClassPool.getDefault();
                classPool.appendClassPath(new LoaderClassPath(ClassLoader.getSystemClassLoader()));
                ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
                if (contextClassLoader != null) {
                    classPool.appendClassPath(new LoaderClassPath(contextClassLoader));
                }

                systemClassPool.add(classPool);
                String targetMethodName = suspiciousClassAndMethod.get(onlyClassName); // get the class only, not package
                System.out.println("targetMethodName: " + targetMethodName);

                return mainProbe(classPool, className, targetMethodName);

            } catch (Exception e) {
                System.out.println("Exception in main probe: " + e.getMessage());
                e.printStackTrace();
            }
        }
//        System.out.println("END Transformer");
        return classfileBuffer;
    }

    private static byte[] mainProbe(ClassPool classPool, String targetClassName, String targetMethodName) {
        if (classPool == null || targetClassName == null || targetMethodName == null) {
            throw new IllegalArgumentException("ClassPool, targetClassName, and targetMethodName must not be null.");
        }

        System.out.println("==================== Probe executed");
        CtClass ctClazz;
        CtMethod ctMethod;
        String fullPathClassName = targetClassName.replace("/", ".");  // Remove the "/" in the className. Ex: Utils/StringUtils -> Utils.StringUtils;
        String insertedCode = generateInsertedCode(); // Extracted code injection

        List<String> targetMethodList = getTargetMethodList(targetMethodName); // Extracted method list creation

        try {
            System.out.println("fullPathClassName: " + fullPathClassName);
            ctClazz = classPool.get(fullPathClassName);
            // =========================================================================
            CtMethod isFrameworkClassMethod = CtNewMethod.make(
                    "private static boolean isFrameworkClass(String className) {" +
                            // Check if the class belongs to a known web framework or server package
                            "return className.startsWith(\"org.apache.\") || className.startsWith(\"javax.servlet.\") || className.startsWith(\"java.\");" +
                            "}", ctClazz);
            ctClazz.addMethod(isFrameworkClassMethod);

            CtMethod isGeneratedJspClassMethod = CtNewMethod.make(
                    "private static boolean isGeneratedJspClass(String className) {" +
                            // Check if the class is a JSP-generated class (often contains 'jsp' or similar patterns)
                            "return className.contains(\"_jsp\") || className.contains(\"$jsp\");" +
                            "}", ctClazz);
            ctClazz.addMethod(isGeneratedJspClassMethod);

// =========================================================================
            for (CtMethod declaredMethod : ctClazz.getDeclaredMethods()) {
                for (String methodName : targetMethodList) {
                    if (declaredMethod.getName().equals(methodName)) {
                        ctMethod = declaredMethod; // Use declaredMethod instead of re-fetch
                        System.out.println("Injecting into CtClass: " + ctClazz.getName() + ", Method: " + ctMethod.getName());
                        ctMethod.insertAfter(insertedCode);
                    }
                }
            }

            byte[] byteCode = ctClazz.toBytecode();
            ctClazz.detach();
            return byteCode;
        } catch (NotFoundException e) {
            throw new RuntimeException("Failed to find the class: " + fullPathClassName, e);
        } catch (CannotCompileException e) {
            throw new RuntimeException("Cannot compile the modified class: " + fullPathClassName, e);
        } catch (IOException e) {
            throw new RuntimeException("I/O error occurred while processing class: " + fullPathClassName, e);
        }
    }

    private static String generateInsertedCode() {
        return "{ " +
                "try { " +
                "    System.out.println(\"=============== PROBE INJECT CODE EXECUTED\"); " +
//                "System.out.println(Thread.currentThread().getContextClassLoader());" +

                "System.out.println(\"Stack trace: \"); " +
                "StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();" +
                "StackTraceElement maliciousClass = null;" +
                "for (int i = 2; i < stackTrace.length; i++) {" +
                "StackTraceElement currentElement = stackTrace[i];" +
                "String currentClassName = currentElement.getClassName();" +

                // Check if the current element is a JSP-generated class
                "if (isGeneratedJspClass(currentClassName)) {" +
                "System.out.println(\"JSP-generated method (potential malicious upload): \" + currentElement.getClassName() + \".\" + currentElement.getMethodName());" +
                "maliciousClass = currentElement.getClassName();" +
                "break;" +
                "}" +

                // If not Java core, keep checking until finding a framework class, set the developer class
                "if (i + 1 < stackTrace.length && !isFrameworkClass(stackTrace[i + 1].getClassName())) {" +
                // Continue until finding a framework class
                "int j = i;" +
                "while (j < stackTrace.length && !isFrameworkClass(stackTrace[j].getClassName())) {" +
                "j++;" +
                "}" +
                // Set the developer class as the current position - 1 and the previous one is malicious
                "if (j < stackTrace.length && isFrameworkClass(stackTrace[j].getClassName())) {" +
                "System.out.println(\"Closest developer method: \" + stackTrace[j - 2].getClassName() + \".\" + stackTrace[j - 2].getMethodName());" +
                "maliciousClass = stackTrace[j - 2].getClassName();" +
                "}" +
                "else if (j < stackTrace.length && isFrameworkClass(stackTrace[j].getClassName()) && !isFrameworkClass(stackTrace[j+1].getClassName())) {\n" +
                " j+=1;" +
                " continue;" +
                "}"+
                "}" +
                "}" +
                "    System.out.println(\"DETECTED MALICIOUS CLASS: \" + maliciousClass); " +
                "String propertyName = \"MAL_\" + maliciousClass + \"_\" + System.currentTimeMillis();" +
                "    java.lang.System.setProperty(propertyName, \"\"+ maliciousClass); " +
                "    System.out.println(\"Set system property successfully: \" + System.getProperty(propertyName)); " +
                "    System.out.println(\"Parameter: \" + $1 +\" , \" + $2 + \" , \" + $3 ); " +
                "    System.out.println(\"END OF PROBE INJECT CODE\"); " +
                "} catch (Exception e) { " +
                "    e.printStackTrace();" +
                "} " +
                "}";

        //        String insertedCode = "{ " +
////                "try {" +
////                "System.setOut(new java.io.PrintStream(new java.io.FileOutputStream(\"D:\\\\Download\\\\output.log\", true))); "
//                "System.out.println(\"=============== PROBE INJECT CODE EXECUTED\"); " +
////                "ClassLoader contextLoader = Thread.currentThread().getContextClassLoader();" +
////                "System.out.println(\"Classloader: \" + ProcessBuilder.class.getClassLoader().getName());" +
////                "System.out.println(\"Context class loader:  \" + contextLoader);" +
//                "System.setProperty(\"testing\",\"HelloWorld\");" +
//                "System.out.println(\"Set system property successfully: \" + System.getProperty(\"testing\") );" +
//
////                "System.out.println(\"Stack trace: \"); " +
////                "StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();" +
////                "for (int i = 0; i < stackTrace.length; i++) { " +
////                "    System.out.println(stackTrace[i]);" +
////                "}" +
////                "System.out.println(\"This message is writt   en to output.log without imports.\");" +
////                "} catch (Exception e) {" +
////                "e.printStackTrace();" +
////                "}" +
////                "boolean addSuccess = org.example.MemoryTransformer.addStackTrace(stackTrace);"+
////                "if (addSuccess) {" +
////                "System.out.println(\"Stack trace added successfully.\");" +
////                "} else {" +
////                "System.out.println(\"Failed to add stack trace.\");}" +
//
//                "System.out.println(\"END OF PROBE INJECT CODE\"); " +
//                "}";

    }

    private static List<String> getTargetMethodList(String targetMethodName) {
        List<String> targetMethodList = new ArrayList<>();
        if (targetMethodName.contains("[") && targetMethodName.contains(",")) {
            String[] targetMethodString = StringUtils.convertToStringArray(targetMethodName);
            targetMethodList.addAll(Arrays.asList(targetMethodString));
        } else {
            targetMethodList.add(targetMethodName);
        }
        return targetMethodList;
    }


//    ====================================================================================================================
//                                                      TESTINGGG!!!!

//    @Override
//    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {
//        String onlyClassName = className.substring(className.lastIndexOf("/") + 1);
//        if (suspiciousClassAndMethod.containsKey(onlyClassName)) {
//            try {
//                System.out.println("Suspicious class detected: " + className);
//                return mainProbe(className, classBeingRedefined, classfileBuffer,true);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        return classfileBuffer;
//    }
//
//    private byte[] mainProbe(String className, Class<?> classBeingRedefined, byte[] classfileBuffer, boolean Convert) throws NotFoundException, CannotCompileException, IOException {
//        System.out.println("Main probe executed !");
//        ClassPool classPool = ClassPool.getDefault();
//        classPool.insertClassPath(new ClassClassPath(classBeingRedefined));
//        CtClass ctClass = classPool.get(className.replace("/", "."));
//
//        String suspiciousMethodName = suspiciousClassAndMethod.get(className.substring(className.lastIndexOf("/") + 1));
//        if (ctClass.isFrozen()) {
//            ctClass.defrost();
//        }
//
//        // Inject probe into the suspicious method
//        for (CtMethod method : ctClass.getDeclaredMethods()) {
//            if (method.getName().equals(suspiciousMethodName)) {
//                System.out.println("Injecting probe into method3333: " + method.getName());
////                method.insertBefore("{ System.out.println(\"Injecting probe executed\"); }");
////                method.insertBefore("{ org.example.MemoryTransformer.addStackTrace(Thread.currentThread().getStackTrace()); }");
//                method.insertBefore("{ " +
//                        "System.out.println(\"CODE INJECTED\");}");
////                        "try { \n Class<?> als = Class.forName(\"org.example.MemoryTransformer\", true, Thread.currentThread().getContextClassLoader()); java.lang.reflect.Method m = cls.getMethod(\"addStackTrace\", StackTraceElement[].class); m.invoke(null, new Object[] { Thread.currentThread().getStackTrace() }); } catch (Exception e) { e.printStackTrace(); } }");
//            }
//        }
//        if (Convert) {
//            byte[] byteCode = ctClass.toBytecode();
//            ctClass.detach();
//            return byteCode;
//        }
//        return "No no no".getBytes();
//    }

    public static void addStackTrace(StackTraceElement[] stackTrace) {
        System.out.println("Add Stack trace executed ");
//        if (stackTrace.length > 2) { // To avoid self-calls
//            for (StackTraceElement s : stackTrace) {
//                System.out.println("Caller: " + s.getClassName() + "." + s.getMethodName());
//            }
        StackTraceElement caller = stackTrace[2];
        System.out.println("Caller: " + caller.getClassName() + "." + caller.getMethodName());
//            dumpCallerClass(caller.getClassName());
//        }
    }

//        System.out.println("Stack trace: ");
//        if (stackTrace.length > 2) { // To avoid self-calls
//            for (StackTraceElement s : stackTrace){
//                System.out.println("Caller: " + s.getClassName() + "." + s.getMethodName());
//            }

//            dumpCallerClass(caller.getClassName());
//        }
//    }
//    =========================================================================================================




//    public static boolean addStackTrace(StackTraceElement[] stackTrace) {
//        int initialSize = stackTraceList.size(); // Get initial size
//
//        stackTraceList.add(stackTrace); // Add the stack trace
//
//        // Check if the size has increased
//        return stackTraceList.size() > initialSize;
//    }

    // Method to retrieve stack traces for further processing
//    public static List<StackTraceElement[]> getStackTraces() {
//        return stackTraceList;
//    }
}