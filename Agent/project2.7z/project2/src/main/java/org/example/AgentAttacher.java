package org.example;

import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class AgentAttacher {

    private static URL getLoaderFileUrl() {
        return AgentAttacher.class.getProtectionDomain().getCodeSource().getLocation();
    }

    public static void main(String[] args) {
        URL loaderFileUrl = getLoaderFileUrl();
//        String agentPath = "D:\\IntelliJ project\\project1\\target\\classes\\org\\example\\testagent.jar";
        String targetPid = null;
        Map<String, String> processMap = listJvmPid();
                try {
                    for (String processId : processMap.keySet()) {
                        String processDisplayName = processMap.get(processId);
                        System.out.println("PID:" + processId + "\tProcessName:" + ("".equals(processDisplayName) ? "NONE" : processDisplayName));
                        if (processDisplayName.toLowerCase().contains(".bootstrap")) {
                            targetPid = processId;
                        }
                    }
                    VirtualMachine vm = VirtualMachine.attach(targetPid);
                    // Load agent
//                    vm.loadAgent(agentFile.getAbsolutePath().replace("%20"," "));
                    vm.loadAgent(new File(loaderFileUrl.toURI()).getAbsolutePath());
                    vm.detach();
                    System.out.println("Agent attached successfully to JVM with PID: " + targetPid);

                } catch (Exception e) {
                    System.err.println("Failed to attach to JVM with PID: " + targetPid);
                    e.printStackTrace();
                }
            }

    public static Map<String, String> listJvmPid() {
        Map<String, String> processMap = new HashMap<String, String>();
        for (VirtualMachineDescriptor vmDescriptor : VirtualMachine.list()) {
            String displayName = vmDescriptor.displayName();
            String targetPid = vmDescriptor.id();
            processMap.put(vmDescriptor.id(),vmDescriptor.displayName());
        }
        return processMap;
    }
}
