package org.example;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class test {
    public static void addStackTrace(StackTraceElement[] stackTrace) {
        if (stackTrace.length > 2) { // To avoid self-calls
            StackTraceElement sensitiveMethod = stackTrace[1];
            System.out.println("Sensitive method: " + sensitiveMethod.getClassName() + "." + sensitiveMethod.getMethodName());
            StackTraceElement maliciousClass = null;

            // Iterate through stack trace to find the JSP-generated or closest framework method
            for (int i = 2; i < stackTrace.length; i++) {
                StackTraceElement currentElement = stackTrace[i];
                String currentClassName = currentElement.getClassName();

                // Check if the current element is a JSP-generated class
                if (isGeneratedJspClass(currentClassName)) {
                    System.out.println("JSP-generated method (potential malicious upload): " + currentElement.getClassName() + "." + currentElement.getMethodName());
                    maliciousClass = currentElement;
                    break;
                }

                // If not Java core, keep checking until finding a framework class, set the developer class
                if (i + 1 < stackTrace.length && !isFrameworkClass(stackTrace[i + 1].getClassName())) {
                    // Continue until finding a framework class
                    int j = i;
                    while (j < stackTrace.length && !isFrameworkClass(stackTrace[j].getClassName())) {
                        j++;
                    }
                    // Set the developer class as the current position - 1 and the previous one is malicious (pos - 2)
                    if (j < stackTrace.length && isFrameworkClass(stackTrace[j].getClassName()) && isFrameworkClass(stackTrace[j+1].getClassName())) {
                        System.out.println("Closest developer method: " + stackTrace[j - 2].getClassName() + "." + stackTrace[j - 2].getMethodName());
                        return;
                    }
                    else if (j < stackTrace.length && isFrameworkClass(stackTrace[j].getClassName()) && !isFrameworkClass(stackTrace[j+1].getClassName())) {
//                        System.out.println("Closest developer method: " + stackTrace[j - 2].getClassName() + "." + stackTrace[j - 2].getMethodName());
                        j+=1;
                        continue;
                    }
                }
            }

            if (maliciousClass != null) {
                System.out.println("Identified malicious class: " + maliciousClass.getClassName() + "." + maliciousClass.getMethodName());
            }
        }
    }

    private static boolean isFrameworkClass(String className) {
        // Check if the class belongs to a known web framework or server package
        return className.startsWith("org.apache.") || className.startsWith("javax.servlet.") || className.startsWith("java.");
    }

    private static boolean isGeneratedJspClass(String className) {
        // Check if the class is a JSP-generated class (often contains 'jsp' or similar patterns)
        return className.contains("_jsp") || className.contains("$jsp");
    }

//    private static void dumpCallerClass(String callerClassName) {
//        try {
//            ClassPool classPool = ClassPool.getDefault();
//            CtClass callerClass = classPool.get(callerClassName);
//            saveBytecodeToFile(callerClass, callerClassName);
//        } catch (NotFoundException | IOException e) {
//            e.printStackTrace();
//        }
//    }

//    private static void saveBytecodeToFile(CtClass ctClass, String className) throws IOException, CannotCompileException {
//        String fileName = className.replace('.', '_') + ".class";
//        File file = new File("/path/to/output/directory/" + fileName);
//        try (FileOutputStream outputStream = new FileOutputStream(file)) {
//            outputStream.write(ctClass.toBytecode());
//            System.out.println("Bytecode saved for class: " + className);
//        }
//    }

    // Test method to verify the closest developer method finder
    public static void main(String[] args) {
//        String stackTraceString = ""+
//            "java.base/java.lang.Thread.getStackTrace(Thread.java:1602)\n"+
//            "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName(FilterDef.java:116)\n"+
//            "org.apache.jsp.uploads._1addFilter_jsp$2.setFilterName(_1addFilter_jsp.java:259)\n"+
//            "org.apache.jsp.uploads._1addFilter_jsp._jspService(_1addFilter_jsp.java:266)\n"+
//            "org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:67)\n"+
//            "javax.servlet.http.HttpServlet.service(HttpServlet.java:623)\n"+
//            "org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:466)\n"+
//            "org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:376)\n";
        String stackTraceString = ""+
                "java.base/java.lang.Thread.getStackTrace(Thread.java:1602)\n"+
                "org.apache.tomcat.util.descriptor.web.FilterDef.setFilterName(FilterDef.java:116)\n"+
                "org.apache.catalina.deploy.FilterDef.setFilterName(Injected.java:116)\n"+
//                "org.Injected.Injected2.$2(Injected.java:116)\n"+
                "org.haha.New.initialize(Injected.java:116)\n"+
                "org.example.UploadServlet.service(MyServlet.java:116)\n"+
                "org.apache.jasper.runtime.HttpJspBase.service(HttpJspBase.java:67)\n"+
                "javax.servlet.http.HttpServlet.service(HttpServlet.java:623)\n"+
                "org.apache.jasper.servlet.JspServletWrapper.service(JspServletWrapper.java:466)\n"+
                "org.apache.jasper.servlet.JspServlet.serviceJspFile(JspServlet.java:376)\n";

        StackTraceElement[] stackTraceElements = parseStackTrace(stackTraceString);
        addStackTrace(stackTraceElements);
    }

    // Helper method to parse a stack trace string into StackTraceElement[]
    private static StackTraceElement[] parseStackTrace(String stackTraceString) {
        String[] lines = stackTraceString.trim().split("\n");
        List<StackTraceElement> stackTraceElements = new ArrayList<>();
        for (String line : lines) {
            line = line.trim();
            if (!line.isEmpty()) {
                String[] parts = line.split("\\(");
                String classAndMethod = parts[0].trim();
                String fileAndLine = parts[1].replace(")", "").trim();
                String[] classAndMethodParts = classAndMethod.split("\\.");
                String methodName = classAndMethodParts[classAndMethodParts.length - 1];
                String className = classAndMethod.substring(0, classAndMethod.lastIndexOf("." + methodName));
                String[] fileAndLineParts = fileAndLine.split(":");
                String fileName = fileAndLineParts[0];
                int lineNumber = Integer.parseInt(fileAndLineParts[1]);
                stackTraceElements.add(new StackTraceElement(className, methodName, fileName, lineNumber));
            }
        }
        return stackTraceElements.toArray(new StackTraceElement[0]);
    }
}
