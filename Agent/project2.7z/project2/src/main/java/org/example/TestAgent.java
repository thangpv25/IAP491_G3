package org.example;

import javassist.*;

import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.util.*;


import static Utils.ClassUtils.*;
import static Utils.StringUtils.extractClassName;
import static org.example.MemoryTransformer.suspiciousClassAndMethod;
import static org.example.MemoryTransformer.systemClassPool;


public class TestAgent {
    protected static List<Class<?>> LOADED_CLASS = new ArrayList<>();

    public static void premain(String agentArgs, Instrumentation inst) {
        agentmain(agentArgs, inst);
    }

    public static void agentmain(String agentArgs, Instrumentation inst)   {
        System.out.println("=================\nAgentmain executed: Test Agent attached.");
        System.out.println("This agent class loader: " + TestAgent.class.getClassLoader());
        ClassLoader contextLoader = Thread.currentThread().getContextClassLoader();
        System.out.println("Ctx Loader: " + contextLoader);
        if (!inst.isRetransformClassesSupported()) {
            System.out.println("Class retransformation is not supported.");
            return;
        }
        handleLoadedClasses(inst);
        inst.addTransformer(new MemoryTransformer());
        try {
            activeListening(inst, false);
        } catch (IOException | CannotCompileException | NotFoundException e) {
            throw new RuntimeException(e);
        }

//        for (Class<?> loadedClass : inst.getAllLoadedClasses()) {
////            System.out.println("Loaded Class: " + loadedClass);
//            if (loadedClass.getName().equals("java.lang.ProcessBuilder")) {
//                System.out.println("Retransform class: " + loadedClass.getName());
//                inst.retransformClasses(loadedClass);
//
//            }
//        }
    }

    public static void handleLoadedClasses(Instrumentation inst) {
        for (String suspiciousClass : suspiciousClassAndMethod.keySet()) {
            if (checkLoaded(inst,suspiciousClass)){
                System.out.println("suspicious class: " + suspiciousClass);
                Class<?> loadedClassObj = getLoadedClassObjByCLassName(inst,suspiciousClass);
//                if (loadedClassObj == null) {
//                    System.out.println("loadedClassObj is null");
//                }

//                System.out.println("Loaded class obj: " + loadedClassObj.getName());
                String tempClassName =null;
                if (loadedClassObj.isArray()) {
                    // Get the underlying component type, which represents the type of the array's elements
                    loadedClassObj = loadedClassObj.getComponentType();
                    // Get the simple name of the component type
                }
//                System.out.println("Loaded class obj after: " + loadedClassObj.getName());
                LOADED_CLASS.add(loadedClassObj);
            }
        }
        if (LOADED_CLASS != null) {
            retransformClasses(inst,new MemoryTransformer(), LOADED_CLASS);
        }
    }
    public static void activeListening(Instrumentation inst, boolean canStop) throws NotFoundException, IOException, CannotCompileException {
        while (!canStop){
            Properties properties = System.getProperties();

            // Iterate over properties to find keys that start with "MAL"
//            System.out.println("System properties starting with 'MAL':");
            for (Map.Entry<Object, Object> entry : properties.entrySet()) {
                String key = String.valueOf(entry.getKey());
                if (key.startsWith("MAL")) {
                    String value = entry.getValue().toString();
                    System.out.println("======================================= FOUND MAL CLASS2");
                    System.out.println(key + " = " +value );
                    if (key.contains("_jsp")){
                        handleJsp(key);
                        System.clearProperty(key);

//                        handleResponse (value);
                        continue;
                    }
                    String className = extractClassName(key);
                    System.out.println("Extracted className = " + className);
                    dumpClass(inst,className);
                    System.clearProperty(key);

                }
            }
        }
    }
    public static void handleJsp (String className){

    }
    public static void dumpClass(Instrumentation inst,  String className) throws NotFoundException, IOException {
        ClassPool classPool = systemClassPool.get(0);
        Class<?> classObj = getLoadedClassObjByFullName(inst,className);
//        System.out.println("classObj test: " + classObj.getName());
        classPool.insertClassPath(new ClassClassPath(classObj));
        CtClass ctClass = classPool.get(className);
        System.out.println("Get successfully: " + ctClass.getName());
        saveBytecodeToFile(ctClass, className);

    }
    public static void printLoadedClass(Instrumentation inst) {
        System.out.println("All loaded classes: ");
        for (Class<?> clazz : inst.getAllLoadedClasses()) {
            if (clazz != null) {
                try {
                    // Get class
//                    if (clazz.getPackage().toString().contains("org.example")) {
//                        String className = clazz.toString();
//                        System.out.println(className);
//                    }
                    System.out.println("Class: " + clazz.getName() + ", Class Loader: " + clazz.getClassLoader());
                } catch (Exception e) {
                    System.err.println("Error finding class: " + e.getMessage());
                }
//
            }
        }

    }

}