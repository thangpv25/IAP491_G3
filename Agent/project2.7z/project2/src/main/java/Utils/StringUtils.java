package Utils;

public class StringUtils {
    public static String[] convertToStringArray(String str) {
        return str.replaceAll("[\\[\\]]", "").split(",\\s*");
    }

    public static String extractClassName(String className) {
        int startIndex = className.indexOf("_") + 1; // Find the index of the first underscore and add 1
        int endIndex = className.lastIndexOf("_"); // Find the last underscore
        return  className.substring(startIndex, endIndex);
    }



}
