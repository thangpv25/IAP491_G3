package org.example.AgentCore;

import javassist.*;
import org.example.Loader.AgentCache;
import org.example.Loader.CustomClassLoader;

import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.util.*;

import static org.example.AgentCore.MemoryTransformer.suspiciousClassAndMethod;
import static org.example.AgentCore.MemoryTransformer.systemClassPool;
import static org.example.Utils.ClassUtils.*;
import static org.example.Utils.InstrumentationUtils.invokeAgentCacheMethodWithCast;
import static org.example.Utils.StringUtils.extractClassName;


public class Worker {
    private org.example.Loader.AgentCache agentCache;
    protected static List<Class<?>> LOADED_CLASS = new ArrayList<>();

    Worker() {
    }

    public static void agentExecution(Instrumentation inst, org.example.Loader.AgentCache agentCache) throws Exception {
        try {
            System.out.println("======================== AgentExecution executed !");
            System.out.println("11AgentCache class: " + agentCache.getClass().getName());
            System.out.println("Worker classloader is " + Worker.class.getClassLoader());

            handleLoadedClasses( inst);
            System.out.println("========= Handled loaded class successfully !");
            ClassFileTransformer memoryTransformer = new MemoryTransformer();

            inst.addTransformer(memoryTransformer, true);
            System.out.println("========= Add memoryTransformer successfully !");

            Set<ClassFileTransformer> test = invokeAgentCacheMethodWithCast(agentCache, "getTransformers", Set.class, false, inst);
            test.add(memoryTransformer);

            Set<ClassFileTransformer> test2 = invokeAgentCacheMethodWithCast(agentCache, "getTransformers", Set.class, false, inst);
            for (ClassFileTransformer cl : test) {
                System.out.println("Transformer: " + cl.toString());
            }
            activeListening(inst, false);
        } catch (Exception e) {
            System.err.println("Error in agentExecution: " + e.getMessage());
            e.printStackTrace();
        }
    }


    public static void handleLoadedClasses(Instrumentation inst) {
        for (String suspiciousClass : suspiciousClassAndMethod.keySet()) {
            if (checkLoaded(inst, suspiciousClass)) {
                System.out.println("suspicious class: " + suspiciousClass);
                Class<?> loadedClassObj = getLoadedClassObjByCLassName(inst, suspiciousClass);
//                if (loadedClassObj == null) {
//                    System.out.println("loadedClassObj is null");
//                }

//                System.out.println("Loaded class obj: " + loadedClassObj.getName());
                String tempClassName = null;
                if (loadedClassObj.isArray()) {
                    // Get the underlying component type, which represents the type of the array's elements
                    loadedClassObj = loadedClassObj.getComponentType();
                    // Get the simple name of the component type
                }
//                System.out.println("Loaded class obj after: " + loadedClassObj.getName());
                LOADED_CLASS.add(loadedClassObj);
            }
        }
        if (LOADED_CLASS != null) {
            retransformClasses(inst, new MemoryTransformer(), LOADED_CLASS);
        }
    }

    public static void activeListening(Instrumentation inst, boolean canStop) throws NotFoundException, IOException, CannotCompileException {
        while (!canStop) {
            Properties properties = System.getProperties();

            // Iterate over properties to find keys that start with "MAL"
//            System.out.println("System properties starting with 'MAL':");
            for (Map.Entry<Object, Object> entry : properties.entrySet()) {
                String key = String.valueOf(entry.getKey());
                if (key.startsWith("MAL")) {
                    String value = entry.getValue().toString();
                    System.out.println("======================================= FOUND MAL CLASS2");
                    System.out.println(key + " = " + value);
                    if (key.contains("_jsp")) {
                        handleJsp(key);
                        System.clearProperty(key);

//                        handleResponse (value);
                        continue;
                    }
                    String className = extractClassName(key);
                    System.out.println("Extracted className = " + className);
                    dumpClass(inst, className);
                    System.clearProperty(key);

                }
            }
        }
    }

    public static void handleJsp(String className) {

    }

    public static void dumpClass(Instrumentation inst, String className) throws NotFoundException, IOException {
        ClassPool classPool = systemClassPool.get(0);
        Class<?> classObj = getLoadedClassObjByFullName(inst, className);
//        System.out.println("classObj test: " + classObj.getName());
        classPool.insertClassPath(new ClassClassPath(classObj));
        CtClass ctClass = classPool.get(className);
        System.out.println("Get successfully: " + ctClass.getName());
        saveBytecodeToFile(ctClass, className);

    }

    public static void printLoadedClass(Instrumentation inst) {
        System.out.println("All loaded classes: ");
        for (Class<?> clazz : inst.getAllLoadedClasses()) {
            if (clazz != null) {
                try {
                    // Get class
//                    if (clazz.getPackage().toString().contains("org.example")) {
//                        String className = clazz.toString();
//                        System.out.println(className);
//                    }
                    System.out.println("Class: " + clazz.getName() + ", Class Loader: " + clazz.getClassLoader());
                } catch (Exception e) {
                    System.err.println("Error finding class: " + e.getMessage());
                }
//
            }
        }

    }
}
